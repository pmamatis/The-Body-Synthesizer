var distortion_8c =
[
    [ "Distortion_Init", "group__Distortion.html#ga54ad82c4a3ecbc0c2784ae81c92eb22e", null ],
    [ "Distortion_Reset", "group__Distortion.html#gac69b82a1179f795d9205a246de59a37a", null ],
    [ "ProcessHardClippingDistortion", "group__Distortion.html#ga7a68b2a90c4306d739161ee82b7eb89c", null ],
    [ "ProcessSoftClippingDistortion", "group__Distortion.html#ga1676e7551d7621b89efb0ecc46092436", null ],
    [ "SetupHardClippingDistortion", "group__Distortion.html#ga2a6725ec967773f5ddfbc3fc21d67049", null ],
    [ "SetupSoftClippingDistortion", "group__Distortion.html#ga8a375c625074dc4492066cda7e9e175b", null ]
];