var sinLUT_8h =
[
    [ "LFO", "group__SINLUT.html#ga8ed6c93a3575a1bca18ba7ae1ab1735a", null ],
    [ "LFO_ENDINDEX", "group__SINLUT.html#gadd64de359bd581eccdc0c439dd3add66", null ],
    [ "LFO_FREQUENCYS", "group__SINLUT.html#gaa9c9ea0c186709ce908f4a8ad5e0975d", null ],
    [ "LFO_STARTINDEX", "group__SINLUT.html#ga56c49e449311b56a93feb559198762fe", null ],
    [ "LFO_SUPPORTPOINTS", "group__SINLUT.html#ga956e265f52e43419b6840913fb23f8d0", null ],
    [ "LUT", "group__SINLUT.html#ga4f12a18a6cf6bdb4cf4b1f3a509f061e", null ],
    [ "LUT_ENDINDEX", "group__SINLUT.html#ga93f6110c104231e7959e446480c94834", null ],
    [ "LUT_FREQUENCYS", "group__SINLUT.html#ga9a9d9181987af97d8c0ee7492f2e17fc", null ],
    [ "LUT_STARTINDEX", "group__SINLUT.html#ga2e5122eebde8d369cf949da93586ec2e", null ],
    [ "LUT_SUPPORTPOINTS", "group__SINLUT.html#ga1380f2886548602aeb7849aa7ba76435", null ]
];