var group__Display =
[
    [ "EPD-Libary variables", "group__EPDLib.html", "group__EPDLib" ],
    [ "Display processing and navigation funtions", "group__DisplayProcess.html", "group__DisplayProcess" ],
    [ "Display Pages", "group__DisplayPage.html", "group__DisplayPage" ],
    [ "display_variables", "structdisplay__variables.html", null ],
    [ "DISPLAY_DeleteDrumcomputerStep", "group__Display.html#ga7759568f4bd60f3d77a2a0e463b77b03", null ],
    [ "DISPLAY_DeleteDrumcomputerStepCursor", "group__Display.html#ga1734a46d569f2b74ad09171b2802ca6b", null ],
    [ "DISPLAY_DeleteSequencerStep", "group__Display.html#ga6b780fda00ecfb80ed28ba3a62937b11", null ],
    [ "DISPLAY_DeleteSequencerStepCursor", "group__Display.html#gab4a4b9b1639809ba234afec57b86facb", null ],
    [ "Display_DrawDrumcomputerIcons", "group__Display.html#ga6f1e5fd55fe52c0da6ed8691a043c7e3", null ],
    [ "DISPLAY_DrawDrumcomputerPattern", "group__Display.html#ga2900e59099c5f0d46df7571a3e9b7352", null ],
    [ "DISPLAY_DrawDrumcomputerPatternFrame", "group__Display.html#gaeee4736127d8842a23ce57021443c5af", null ],
    [ "Display_DrawSequencerIcons", "group__Display.html#gaf6dae7f8bd4125cda81cd0a03749adf2", null ],
    [ "DISPLAY_DrawSequencerPattern", "group__Display.html#ga2f33d0a9945e16984c8e31dc9b145c01", null ],
    [ "DISPLAY_DrawSequencerPatternFrame", "group__Display.html#ga3270139a5529761a3c6cc482e8a83367", null ],
    [ "Display_LoadDrumKits", "group__Display.html#gafeebe386ce2f442752742b054674b40d", null ],
    [ "DISPLAY_SetDrumcomputerStep", "group__Display.html#gacc64d5980c2033bd470353f22af60a7a", null ],
    [ "DISPLAY_SetDrumcomputerStepCursor", "group__Display.html#ga6e1ecb52e8edebcd426cb409104aac47", null ],
    [ "DISPLAY_SetSequencerStep", "group__Display.html#ga9d7e433c8b0a75b8ffdfa1ffe817c2f1", null ],
    [ "DISPLAY_SetSequencerStepCursor", "group__Display.html#gacb106feb27895b4c32f2cd8770842848", null ]
];