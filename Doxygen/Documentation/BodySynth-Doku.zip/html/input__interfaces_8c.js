var input__interfaces_8c =
[
    [ "II_decreaseNote", "group__InputInterface.html#gafa7d9063c65151e6c6c79e94f81dd0fd", null ],
    [ "II_Display_Effects", "group__InputInterface.html#ga195e0c4273ec6831366f4ae54a1586ee", null ],
    [ "II_init", "group__InputInterface.html#gaf102c42e8c8be931b33bd67401dd9424", null ],
    [ "II_raiseNote", "group__InputInterface.html#ga2b27d1c554db52f823b2897137823819", null ],
    [ "II_startInterface", "group__InputInterface.html#ga3c55c248a4e6b89d5698af2b46e35b60", null ],
    [ "gyro_toggleCounter", "input__interfaces_8c.html#a6d6f063b2586502895f157d0c13455f1", null ]
];