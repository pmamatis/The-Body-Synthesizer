var group__LUT =
[
    [ "atan() LUT", "group__atanLUT.html", "group__atanLUT" ],
    [ "Sinus LUT", "group__SINLUT.html", "group__SINLUT" ],
    [ "WAV-LUT", "group__wavlut.html", null ]
];