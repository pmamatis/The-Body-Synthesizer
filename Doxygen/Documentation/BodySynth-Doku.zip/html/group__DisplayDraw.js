var group__DisplayDraw =
[
    [ "DISPLAY_ArrowDown", "group__DisplayDraw.html#ga44502944f0f57e797ed44a9d81e533e8", null ],
    [ "DISPLAY_ArrowUp", "group__DisplayDraw.html#ga66ef522eba7da71e294cabcccdd89adf", null ],
    [ "DISPLAY_DrawArrow", "group__DisplayDraw.html#ga4170023d4ce93f468b83d6bd0f5c316d", null ],
    [ "DISPLAY_PrintCurrentPage", "group__DisplayDraw.html#ga04813dcc16532f2222d2a9d799d98f30", null ],
    [ "DISPLAY_SwitchPageLeft", "group__DisplayDraw.html#gaad139dccbdea27c5c95092b327408a1a", null ],
    [ "DISPLAY_SwitchPageRight", "group__DisplayDraw.html#ga6762942b296dabc3a6cfa0f14bd1c690", null ],
    [ "DISPLAY_Update", "group__DisplayDraw.html#ga0cf58d71eacb3fad194c7257fd5ce183", null ]
];