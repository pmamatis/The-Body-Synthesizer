var emg_8c =
[
    [ "ecg_heartrate", "group__EMG__ECG.html#ga6ad14645e09a9e49124abbb14199027f", null ],
    [ "ecg_init", "group__EMG__ECG.html#ga98bf9a8015f7a7833276fbf6a72e255e", null ],
    [ "emg_init", "group__EMG__ECG.html#gaa7d92b6a1983e52614915f8e2cfb3140", null ],
    [ "emg_peak_detection", "group__EMG__ECG.html#ga63f5337cb5d5feb55ddedd79bca265d9", null ],
    [ "emg_start_read", "group__EMG__ECG.html#gad8539de6db12ec20b070f6fb97f99a73", null ],
    [ "emg_stop_read", "group__EMG__ECG.html#ga305d3a0240c6e197a771b26c8d4fd22a", null ]
];