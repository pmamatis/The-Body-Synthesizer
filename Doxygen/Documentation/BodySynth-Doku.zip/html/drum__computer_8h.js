var drum__computer_8h =
[
    [ "FourFour", "group__DrumComputer.html#ga267b06d60a7514d898b5cac91b4380ec", null ],
    [ "Drum_Computer_CalcSample", "group__DrumComputer.html#gab1eca379f4f1b927be94270e748a87bf", null ],
    [ "Drum_Computer_Init", "group__DrumComputer.html#ga98c7a5f46d897df7157cfd75e379afb3", null ],
    [ "Drum_Computer_Process", "group__DrumComputer.html#ga08535ad247ef4e17b91bbba4b56833af", null ],
    [ "Drum_Computer_Reset", "group__DrumComputer.html#ga0945a49b026be615b8a70c8ec885ac08", null ],
    [ "PlaySingleSample", "group__SingleSample.html#gab788a1e344e6956cb70a8e5e1ea4d0bd", null ],
    [ "Sequencer_ADSR_Init", "group__Sequencer.html#gafe5a4ffde057a9bf69f40122bd7fee59", null ],
    [ "Sequencer_Reset", "group__Sequencer.html#gaf1fa77afa44aa624f611ecb1bcb9117e", null ],
    [ "BPM", "group__DrumComputer.html#ga0065e192c774e20fd5e0ab3c342b7088", null ],
    [ "counter_master", "group__DrumComputer.html#ga148d70203e23260f999890046d5509b0", null ],
    [ "current_LUT_index_SN1", "group__Sequencer.html#gabafd5c3bbb1d0bbc3e708889e904e3a7", null ],
    [ "drum_index", "group__DrumComputer.html#gad32e19a8282780d0a134ec07797ac10b", null ],
    [ "DS1s", "group__DrumComputer.html#ga1d0ce949a258b04a5822d3442fd73d83", null ],
    [ "flag_DS1", "group__DrumComputer.html#ga88744615d25a485f31d6718453e6d324", null ],
    [ "freq_index_SN1", "group__Sequencer.html#ga4211ba08e77d82a294762a623041e342", null ],
    [ "timing_DS1", "group__DrumComputer.html#ga4c0fb828065d1505aa1abfdd52afc7c3", null ]
];