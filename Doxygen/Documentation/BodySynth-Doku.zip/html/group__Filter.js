var group__Filter =
[
    [ "BQFilter", "structBQFilter.html", null ],
    [ "DrumFilters_Reinit_Gyro", "group__Filter.html#ga251962656e367a604dfd084fabcc7076", null ],
    [ "Equalizer_Reset", "group__Filter.html#gab23086039f9e38c9538b24412c2e397d", null ],
    [ "Filters_Init", "group__Filter.html#ga44cc78d9063ea994317ac57c15b6eced", null ],
    [ "Filters_Reinit_Gyro", "group__Filter.html#gaec8e59a44285b5c5d026199e59bedc1d", null ],
    [ "Filters_Reinit_Poti", "group__Filter.html#gadcc644218f3fbdbd5725f157286c155f", null ],
    [ "ProcessEQ", "group__Filter.html#gaa615f53296529b29ed116c17bf41f422", null ],
    [ "ProcessFilter", "group__Filter.html#gad95e18a35a0ebacf27bc67222a71e275", null ],
    [ "SetupBandpassCPG", "group__Filter.html#ga30d8b183489ac4208a5fe11ba3a5dd40", null ],
    [ "SetupBandpassCSG", "group__Filter.html#ga3c5c39d8c8ea89c55cc12218899dbc7c", null ],
    [ "SetupHighpass", "group__Filter.html#gadf56f507b61ffa882eb78b346dec0f05", null ],
    [ "SetupHighShelf", "group__Filter.html#ga03fcfa1037c98ff029c9fb59f6c312dc", null ],
    [ "SetupLowpass", "group__Filter.html#ga1d45e64aaa786258dd8d43d5fd8e8cbe", null ],
    [ "SetupLowShelf", "group__Filter.html#ga1345bd0312350f65e08e824e6413f219", null ],
    [ "SetupNotch", "group__Filter.html#gacb256e7bd3b663acfe846603e95f851a", null ],
    [ "SetupPeakingEQ", "group__Filter.html#gae324262d60a906226a1ddf27ba0860b9", null ]
];