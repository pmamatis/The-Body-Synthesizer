var tremolo_8c =
[
    [ "ProcessTremolo", "group__tremolo.html#ga922840d8712ad7bd4904f7813c8ac2f6", null ],
    [ "Tremolo_Init", "group__tremolo.html#gacb90f3df18e98cac0b0aadc519411a7a", null ],
    [ "Tremolo_Reset", "group__tremolo.html#ga7ec31bc72214199a5efdbe88b3a3f8b8", null ]
];