var group__Sequnecer =
[
    [ "Sequencer_ADSR_Init", "group__Sequnecer.html#gafe5a4ffde057a9bf69f40122bd7fee59", null ],
    [ "Sequencer_Reset", "group__Sequnecer.html#gaf1fa77afa44aa624f611ecb1bcb9117e", null ]
];