var wav_8h =
[
    [ "WAV_FORMAT_PCM", "wav_8h.html#a7ff724a7e59219c82177925476950735", null ],
    [ "wav_eof", "wav_8h.html#a2ae347cfdc40d636285968e72294eb8c", null ],
    [ "wav_errno", "wav_8h.html#a689b248101c33cc0412d625f497396ba", null ],
    [ "wav_error", "wav_8h.html#af241642229468a37ee36ca86a06978a9", null ],
    [ "wav_open", "wav_8h.html#a36022ae34482d520db9e14d7e056bcbf", null ],
    [ "wav_read", "wav_8h.html#a9a818bd7facdfcce273c04ed41c99f68", null ],
    [ "wav_set_format", "wav_8h.html#a129bf98b4d0805e7068dbbba3ce9119c", null ],
    [ "wav_set_num_channels", "wav_8h.html#afc5fb77381d285f3bab78cb6b263db00", null ],
    [ "wav_set_sample_rate", "wav_8h.html#aec804cebb962f82451f2a7efca41cf8a", null ],
    [ "wav_set_sample_size", "wav_8h.html#a4505192e4d2b0dae0cec1421af9c8e9f", null ],
    [ "wav_set_valid_bits_per_sample", "wav_8h.html#a50becd30ff6f8fcc4b42c84ff2df42b8", null ],
    [ "wav_tell", "wav_8h.html#aa990c8c22d5039769d35f7cdae28310d", null ],
    [ "wav_write", "wav_8h.html#a9d988d0342d7c19394e8e0f29d26e485", null ]
];