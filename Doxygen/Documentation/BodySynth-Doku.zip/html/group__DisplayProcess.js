var group__DisplayProcess =
[
    [ "DISPLAY_ArrowDown", "group__DisplayProcess.html#ga44502944f0f57e797ed44a9d81e533e8", null ],
    [ "DISPLAY_ArrowUp", "group__DisplayProcess.html#ga66ef522eba7da71e294cabcccdd89adf", null ],
    [ "DISPLAY_DrawArrow", "group__DisplayProcess.html#ga4170023d4ce93f468b83d6bd0f5c316d", null ],
    [ "Display_Init", "group__DisplayProcess.html#ga11f29ac6ffffd64bb9c21e37c0b6e7ce", null ],
    [ "DISPLAY_PrintCurrentPage", "group__DisplayProcess.html#ga04813dcc16532f2222d2a9d799d98f30", null ],
    [ "DISPLAY_processing", "group__DisplayProcess.html#ga58ba5f4736b652ed76bbb23f7d2cbe0e", null ],
    [ "Display_Start", "group__DisplayProcess.html#gad30227eebb2921ea58a7bc2c82cb33ab", null ],
    [ "DISPLAY_SwitchPageLeft", "group__DisplayProcess.html#gaad139dccbdea27c5c95092b327408a1a", null ],
    [ "DISPLAY_SwitchPageRight", "group__DisplayProcess.html#ga6762942b296dabc3a6cfa0f14bd1c690", null ],
    [ "DISPLAY_Update", "group__DisplayProcess.html#ga0cf58d71eacb3fad194c7257fd5ce183", null ]
];