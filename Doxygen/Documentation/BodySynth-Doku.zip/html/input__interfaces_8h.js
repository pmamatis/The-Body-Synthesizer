var input__interfaces_8h =
[
    [ "II_TREM_RATE_DELAY", "group__InputInterface.html#gac6dc998476a80037e675ac210e8fe275", null ],
    [ "II_decreaseNote", "group__InputInterface.html#gafa7d9063c65151e6c6c79e94f81dd0fd", null ],
    [ "II_Display_Effects", "group__InputInterface.html#ga195e0c4273ec6831366f4ae54a1586ee", null ],
    [ "II_init", "group__InputInterface.html#gaf102c42e8c8be931b33bd67401dd9424", null ],
    [ "II_raiseNote", "group__InputInterface.html#ga2b27d1c554db52f823b2897137823819", null ],
    [ "II_startInterface", "group__InputInterface.html#ga3c55c248a4e6b89d5698af2b46e35b60", null ],
    [ "filter_step_counter", "group__InputInterface.html#ga18a2130fd54d97626562fa2719aae572", null ],
    [ "gyro_delay_counter", "group__InputInterface.html#ga76749a61b9d1cc989220f945bd8cbba2", null ],
    [ "gyrochanged", "group__InputInterface.html#ga192acf54301f05c84432d895bfc661e6", null ],
    [ "log_mapping_F", "group__InputInterface.html#gad50ffb5e3431bdf97736f4dab39c252d", null ]
];