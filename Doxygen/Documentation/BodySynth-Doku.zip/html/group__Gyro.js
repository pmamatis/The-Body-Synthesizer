var group__Gyro =
[
    [ "sensor_data", "structsensor__data.html", null ],
    [ "tilt_direction_t", "group__Gyro.html#gabbffa66db1c27e631e55fe54973212b2", null ],
    [ "tilt_direction_t", "group__Gyro.html#ga7021b2a1eb586b74239bbfa19f42724a", null ],
    [ "spiC_Init", "group__Gyro.html#ga87e70ebae58b5e371289ad557bb31b74", null ]
];