var group__DisplayPage =
[
    [ "Display_LoadSingleSample", "group__DisplayPage.html#gadf582a2e8ef7f900542820189b94f22d", null ],
    [ "Full_Reset", "group__DisplayPage.html#ga84ad5e4c5b1f9dca651caf624ed02d91", null ],
    [ "p_ADSR_overview", "group__DisplayPage.html#ga9c50283b04038fadbf006a1a7ecf27c8", null ],
    [ "p_ADSR_Settings", "group__DisplayPage.html#ga59adc18e5d5ce7fc2cfa665772b52302", null ],
    [ "p_Distortion", "group__DisplayPage.html#ga1165fc18d03b690c887a8e8de4286a53", null ],
    [ "p_Drumcomputer_overview", "group__DisplayPage.html#gae23937cde028cc1e90910692e6a2c6a4", null ],
    [ "p_Drumcomputer_Settings", "group__DisplayPage.html#gaf9d7f7add0e2f3d4bc2d56c1b4803d97", null ],
    [ "p_EMG", "group__DisplayPage.html#gae9490b1e7da6a8a226cf5065174d5ae3", null ],
    [ "p_Equalizer_overview", "group__DisplayPage.html#ga98cc1f263ddc00ac8fbf80266616ce1c", null ],
    [ "p_Equalizer_Settings", "group__DisplayPage.html#ga7b732b0224608d1d160f657ee80e3b6e", null ],
    [ "p_KeyAndMode", "group__DisplayPage.html#ga3123aab8377a46e24d0b13a17c68aa19", null ],
    [ "p_Presets", "group__DisplayPage.html#gabd2a92e2609f00be1f6dd91508ac20d8", null ],
    [ "p_Sequencer_overview", "group__DisplayPage.html#ga8c0c367ef7802a6af877619b174d12ec", null ],
    [ "p_Sequencer_Settings", "group__DisplayPage.html#ga9eb195ca66d081452b9af0da2689dae2", null ],
    [ "p_StartingMenu", "group__DisplayPage.html#ga7b8ca052b8ac8db5ac68f7cbe53ae494", null ],
    [ "p_Tremolo", "group__DisplayPage.html#ga89b9c4137cc59fe857a1a6cdcaffc0a9", null ],
    [ "p_Voices_overview", "group__DisplayPage.html#ga349ac6f6068d46a199b473139123f0be", null ],
    [ "p_Voices_Settings", "group__DisplayPage.html#ga43359da16507588edd1fe90f3ced9222", null ],
    [ "p_Volume", "group__DisplayPage.html#gaa562906df4ccbd2259ec2436685c418f", null ],
    [ "p_WahWah_overview", "group__DisplayPage.html#gaf744a311b39e043299b23b94ce5b0f7c", null ],
    [ "p_WahWah_Settings", "group__DisplayPage.html#ga7a0c5167cd2dd7640095ed836806993a", null ]
];