var SPI__Connection_8h =
[
    [ "tilt_direction_t", "group__Gyro.html#gabbffa66db1c27e631e55fe54973212b2", null ],
    [ "tilt_direction_t", "group__Gyro.html#ga7021b2a1eb586b74239bbfa19f42724a", [
      [ "TILT_NONE", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aac15db6617b6d75771d4fc5ad594840c2", null ],
      [ "TILT_RIGHT", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa2f73f5a7102cebafa1dd0751809c02cc", null ],
      [ "TILT_LEFT", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa42cbd6891ebe8c73911ab41e3c7eb59b", null ],
      [ "TILT_FRONT", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa1558ebf4b18a4f4efd7318046224bdbb", null ],
      [ "TILT_BACK", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa1c9f56eeaef8a44aa138171c797853c8", null ],
      [ "TILT_RIGHT_S", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa09638f6bef6243218ac8a87445f0b393", null ],
      [ "TILT_LEFT_S", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aaa8ae8137706dd5d7fd253379fc372e9f", null ],
      [ "TILT_FRONT_S", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa93e216bb1b38b499aca320c67e887078", null ],
      [ "TILT_BACK_S", "group__Gyro.html#gga7021b2a1eb586b74239bbfa19f42724aa37df8dfaa9b0f1f19b98be26897a8111", null ]
    ] ],
    [ "spiC_Init", "group__Gyro.html#ga87e70ebae58b5e371289ad557bb31b74", null ]
];