var SPI__Connection_8c =
[
    [ "spiC_Init", "group__Gyro.html#ga87e70ebae58b5e371289ad557bb31b74", null ]
];