var group__SoundSynth =
[
    [ "Drumcomputer", "group__DrumComputer.html", "group__DrumComputer" ],
    [ "Sequencer", "group__Sequencer.html", "group__Sequencer" ],
    [ "Play Single Sample", "group__SingleSample.html", "group__SingleSample" ],
    [ "Music Notes", "group__MusicNotes.html", "group__MusicNotes" ]
];