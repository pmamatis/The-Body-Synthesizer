var filters_8c =
[
    [ "DrumFilters_Reinit_Gyro", "group__Filters.html#ga251962656e367a604dfd084fabcc7076", null ],
    [ "Equalizer_Reset", "group__Filters.html#gab23086039f9e38c9538b24412c2e397d", null ],
    [ "Filters_Init", "group__Filters.html#ga44cc78d9063ea994317ac57c15b6eced", null ],
    [ "Filters_Reinit_Gyro", "group__Filters.html#gaec8e59a44285b5c5d026199e59bedc1d", null ],
    [ "Filters_Reinit_Poti", "group__Filters.html#gadcc644218f3fbdbd5725f157286c155f", null ],
    [ "ProcessEQ", "group__Filters.html#gaa615f53296529b29ed116c17bf41f422", null ],
    [ "ProcessFilter", "group__Filters.html#gad95e18a35a0ebacf27bc67222a71e275", null ],
    [ "SetupBandpassCPG", "group__Filters.html#ga30d8b183489ac4208a5fe11ba3a5dd40", null ],
    [ "SetupBandpassCSG", "group__Filters.html#ga3c5c39d8c8ea89c55cc12218899dbc7c", null ],
    [ "SetupHighpass", "group__Filters.html#gadf56f507b61ffa882eb78b346dec0f05", null ],
    [ "SetupHighShelf", "group__Filters.html#ga03fcfa1037c98ff029c9fb59f6c312dc", null ],
    [ "SetupLowpass", "group__Filters.html#ga1d45e64aaa786258dd8d43d5fd8e8cbe", null ],
    [ "SetupLowShelf", "group__Filters.html#ga1345bd0312350f65e08e824e6413f219", null ],
    [ "SetupNotch", "group__Filters.html#gacb256e7bd3b663acfe846603e95f851a", null ],
    [ "SetupPeakingEQ", "group__Filters.html#gae324262d60a906226a1ddf27ba0860b9", null ]
];