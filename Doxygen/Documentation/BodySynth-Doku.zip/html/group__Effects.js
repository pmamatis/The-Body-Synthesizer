var group__Effects =
[
    [ "ADSR Effect", "group__ADSR.html", "group__ADSR" ],
    [ "Distortion Effect", "group__Distortion.html", "group__Distortion" ],
    [ "Effect processing", "group__EffectProcessing.html", "group__EffectProcessing" ],
    [ "Filters", "group__Filters.html", "group__Filters" ],
    [ "Tremolo Effect", "group__tremolo.html", "group__tremolo" ],
    [ "Wahwah Effect", "group__wahwah.html", "group__wahwah" ]
];