var effects_8h =
[
    [ "effects_add", "group__EffectProcessing.html#ga4dfb093ad0f349af12ad3030a11da8d9", null ],
    [ "effects_delete", "group__EffectProcessing.html#ga050a7ed0cb582067293e423a9c3fd7a9", null ],
    [ "keyboard_adsr_process", "group__EffectProcessing.html#ga3f7370371217adca4b93419901dc1c1f", null ],
    [ "effect_order", "group__EffectProcessing.html#ga356f7e77328d3524cc7c5592b2237823", null ]
];