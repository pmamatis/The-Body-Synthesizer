var group__EMG =
[
    [ "ecg_heartrate", "group__EMG.html#ga6ad14645e09a9e49124abbb14199027f", null ],
    [ "ecg_init", "group__EMG.html#ga98bf9a8015f7a7833276fbf6a72e255e", null ],
    [ "emg_peak_detection", "group__EMG.html#ga63f5337cb5d5feb55ddedd79bca265d9", null ],
    [ "emg_start_read", "group__EMG.html#gad8539de6db12ec20b070f6fb97f99a73", null ],
    [ "emg_stop_read", "group__EMG.html#ga305d3a0240c6e197a771b26c8d4fd22a", null ]
];