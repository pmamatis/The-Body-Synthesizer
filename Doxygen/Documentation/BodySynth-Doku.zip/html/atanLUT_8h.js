var atanLUT_8h =
[
    [ "aquidistance", "group__atanLUT.html#ga5b267ef41aab26158640ba93071f0b97", null ],
    [ "atan_LUT_y", "group__atanLUT.html#ga44717ae85351202c8833c3880a6ef9e8", null ]
];