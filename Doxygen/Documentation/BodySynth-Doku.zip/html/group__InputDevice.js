var group__InputDevice =
[
    [ "EMG and ECG sensor processing", "group__EMG__ECG.html", "group__EMG__ECG" ],
    [ "Keyboard", "group__keyboard.html", "group__keyboard" ],
    [ "Groyscop- and Accelerometer-Sensor SPI connection", "group__Gyro.html", "group__Gyro" ]
];