var group__wahwah =
[
    [ "WahWah_t", "structWahWah__t.html", null ],
    [ "ProcessAutoWahWah", "group__wahwah.html#ga85d3b2ed1cf4a3aef7b32c97b2e64237", null ],
    [ "ProcessWahWah", "group__wahwah.html#ga2fa3b9f5777f0876da0b828ee333673a", null ],
    [ "WahWah_Init", "group__wahwah.html#gafdc2b53d4cc3352bf6e51df974ce169e", null ],
    [ "WahWah_Reset", "group__wahwah.html#ga9b91a7fae64755689936b60cf1820535", null ]
];