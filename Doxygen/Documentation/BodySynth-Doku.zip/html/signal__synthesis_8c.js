var signal__synthesis_8c =
[
    [ "AWGN_generator", "signal__synthesis_8c.html#ac23864825289dd0157a0abf76c915b70", null ],
    [ "CalcRectSample", "signal__synthesis_8c.html#a2b8c4b7d554c97fbb68f2226c8202acd", null ],
    [ "CalcTriangleSample", "signal__synthesis_8c.html#abeac1ddb99c3d1374df2dc163a756072", null ],
    [ "DeleteSignal", "signal__synthesis_8c.html#aff4b96bd9a6fb74a10215a54f141d06d", null ],
    [ "IDtoIndex", "signal__synthesis_8c.html#a100668ad3cefb7abc0f65f866ea508ba", null ],
    [ "LFO_SingleValueProcess", "signal__synthesis_8c.html#a381bb27bca64ed7f5df822a3db09707a", null ],
    [ "NewSignal", "signal__synthesis_8c.html#a15e519685bb7a5374c0ea7e3b9980952", null ],
    [ "Noise_Generator", "signal__synthesis_8c.html#a2f9745c8cd2b522e949b4c58cfccce56", null ],
    [ "SetTimerSettings", "signal__synthesis_8c.html#adc7b4110b68d58532096fe9f817df89c", null ],
    [ "Signal_Synthesis", "signal__synthesis_8c.html#a14e563872b7cc3bae6f534d36f016911", null ],
    [ "Signal_Synthesis_Init", "signal__synthesis_8c.html#a9eda288feb5c689a0f90742249fe6da0", null ],
    [ "Voices_Reset", "signal__synthesis_8c.html#af4829c3aeeaf3dbcda0b5266e2834898", null ],
    [ "maxValueDAC", "signal__synthesis_8c.html#ac19aecb2f04b87bf170233b3236093ae", null ],
    [ "ramp_counter", "signal__synthesis_8c.html#a406aefd47c82521bb2c5a14ef93c85d2", null ]
];