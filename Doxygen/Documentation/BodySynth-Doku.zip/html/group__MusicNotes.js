var group__MusicNotes =
[
    [ "Get_Keyindex", "group__MusicNotes.html#ga24334366425c42178a955c3c969ad9a8", null ],
    [ "Get_Note_Frequency", "group__MusicNotes.html#ga3fc1bdf03e12b5dee3aa887f100421bf", null ],
    [ "Get_Note_Index", "group__MusicNotes.html#ga71407d53f2b1100f1ab93dc2681dfe48", null ],
    [ "chord_5", "group__MusicNotes.html#gaf387d96b9f2a32b87121e2eae2c5ff16", null ],
    [ "keys", "group__MusicNotes.html#gaa6edf4563731abf1927b342c5ebe3e8a", null ],
    [ "major_chords", "group__MusicNotes.html#ga2222edaa79f27840e9e26c4d0076bd8c", null ],
    [ "major_scale", "group__MusicNotes.html#ga4e77e1cf22732d27ec948ba6f3942187", null ]
];