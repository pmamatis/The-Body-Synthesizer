/*
 * MotionDetection.h
 *
 *  Created on: Jul 10, 2021
 *      Author: paul
 */

#ifndef INC_MOTIONDETECTION_H_
#define INC_MOTIONDETECTION_H_

#include "MPU6050_GY521.h"

#endif /* INC_MOTIONDETECTION_H_ */
